# Fire Arrow TNT Cart — v4.0.0

Bắn tên lửa cháy → tự động đặt **Rail + TNT Minecart** tại điểm chạm đất.

## Thay đổi v4

| | v3 (cũ) | v4 (mới) |
|---|---|---|
| **Delay đặt Rail→Cart** | 95ms (cố định) | 40ms ± 15ms (jitter) |
| **Delay restore slot** | 60ms (cố định) | 20ms ± 10ms (jitter) |
| **Queue size** | 3 | 8 |
| **Bug lâu lâu không đặt** | ✗ (busy flag không reset) | ✔ Fixed (finally block) |
| **Nút bật/tắt** | ✗ | ✔ Phím **G** (đổi được trong Controls) |
| **Worker crash** | Chết thầm | Tự phục hồi |
| **Trigger window** | 8 tick | 10 tick |

## Cách dùng

1. Cầm **bow** và **flame** enchant (hoặc bật lửa tên bằng `/fire`)
2. Có **Rail** và **TNT Minecart** trong hotbar
3. Bắn tên — Rail + Cart tự đặt tại điểm rơi
4. Nhấn **G** để bật/tắt mod (hiện HUD actionbar)

## Anti-cheat

- Silent rotation (server thấy đúng, camera không giật)
- Jitter ngẫu nhiên mô phỏng human reaction time
- Tick-sync trước mỗi packet
- Giới hạn tầm đặt ≤ 4.5 block

## Build

```
./gradlew build
```
Jar output: `build/libs/fire-arrow-tnt-4.0.0.jar`
