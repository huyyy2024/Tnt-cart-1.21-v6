package com.firebow;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FireBowClient implements ClientModInitializer {
    public static final String  MOD_ID  = "firebow";
    public static final Logger  LOGGER  = LoggerFactory.getLogger(MOD_ID);

    // Keybind mặc định: G (dễ nhớ, ít xung đột)
    // Người dùng có thể đổi trong Options → Controls → FireBow
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[FireBow] v4 loaded. Toggle: G");

        // Đăng ký keybind
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.firebow.toggle",           // translation key
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,               // phím G
            "category.firebow"             // category trong Controls menu
        ));

        // Tick event để check keybind
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                FireBowRuntime rt = FireBowRuntime.get();
                rt.toggle();
                boolean on = rt.isEnabled();

                // Hiện thông báo HUD
                if (client.player != null) {
                    client.player.sendMessage(
                        Text.literal(on
                            ? "§a[FireBow] §fBật ✔"
                            : "§c[FireBow] §fTắt ✘"),
                        true  // actionbar (không spam chat)
                    );
                }

                LOGGER.info("[FireBow] toggled -> {}", on ? "ON" : "OFF");
            }
        });
    }
}
