package com.firebow;

/**
 * Shared toggle state — truy cập từ cả keybind handler lẫn mixin.
 * Dùng FireBowRuntime.get().isEnabled() để đọc, .toggle() để bật/tắt.
 */
public final class ModState {
    private ModState() {}
}
