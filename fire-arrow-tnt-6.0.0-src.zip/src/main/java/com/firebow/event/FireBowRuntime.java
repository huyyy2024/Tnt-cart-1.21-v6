package com.firebow.event;

import com.firebow.util.AsyncRunner;
import com.firebow.util.RotationUtil;
import com.firebow.util.TickSynchronizer;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ThreadLocalRandom;

/**
 * FireBowRuntime v6 — Universal anti-cheat bypass:
 *
 * FIX 1 — Rotation gradual (không teleport):
 *   Thay vì set yaw/pitch ngay lập tức, lerp dần qua nhiều tick.
 *   Trông như người thực sự nhìn vào block.
 *
 * FIX 2 — Swing arm trước khi đặt:
 *   swingHand() gửi packet swing, sau đó mới interactBlock.
 *   Grim/Vulcan check sequence: swing → interact. Thiếu swing = flag.
 *
 * FIX 3 — Timing variance cao hơn:
 *   Delay không cố định mà gaussian random (~human reaction distribution).
 *   Tránh pattern detection theo thời gian.
 *   Min delay 80ms (human plausible).
 *
 * FIX 4 — Slot switch có pre-delay:
 *   Trước khi switch slot, chờ 1 tick (giống người dùng scroll wheel).
 *   Không switch quá nhanh liên tiếp.
 *
 * FIX 5 — Cooldown giữa các lần dùng:
 *   Nếu vừa đặt xong < 600ms trước → skip.
 *   Người thực không bắn tên liên tục mỗi 100ms.
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Timing — tất cả >= 80ms để human-plausible
    // Gaussian: mean ± stddev để tránh pattern
    private static final long ROTATION_STEP_MS    = 16L;  // 1 tick per step
    private static final long ROTATION_STEPS      = 3L;   // 3 tick lerp = ~50ms
    private static final long PRE_SLOT_DELAY_MS   = 80L;  // scroll wheel feel
    private static final long RAIL_TO_CART_MS     = 110L; // mean
    private static final long RAIL_TO_CART_STD    = 25L;  // stddev
    private static final long SLOT_RESTORE_MS     = 90L;
    private static final long SLOT_RESTORE_STD    = 20L;
    private static final long MIN_ACTION_GAP_MS   = 600L; // cooldown giữa 2 lần

    private final Queue<BlockPos>  queue       = new ConcurrentLinkedQueue<>();
    private final AtomicBoolean    busy        = new AtomicBoolean(false);
    private final TickSynchronizer tickSync    = new TickSynchronizer();
    private final AtomicLong       estimatedPingMs = new AtomicLong(50L);
    private volatile long          lastActionMs    = 0L;

    private long lastTickTimeMs = 0;
    private long tickCount      = 0;

    private static final int MAX_QUEUE = 8;
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }
    public void    setEnabled(boolean v) { enabled = v; }
    public long    getPingMs()           { return estimatedPingMs.get(); }

    public void enqueue(BlockPos railPos) {
        if (!enabled) return;
        if (queue.contains(railPos)) return;
        // Cooldown check — tránh spam liên tục
        if (System.currentTimeMillis() - lastActionMs < MIN_ACTION_GAP_MS) return;
        if (queue.size() < MAX_QUEUE) queue.add(railPos);
        if (!busy.get()) processNext();
    }

    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        updatePingEstimate(client);
        if (!queue.isEmpty() && !busy.get()) processNext();
    }

    private void updatePingEstimate(MinecraftClient client) {
        long now = System.currentTimeMillis();
        if (lastTickTimeMs == 0) { lastTickTimeMs = now; return; }
        lastTickTimeMs = now;
        tickCount++;
        if (tickCount > 20 && client.getNetworkHandler() != null) {
            try {
                var entry = client.getNetworkHandler().getPlayerListEntry(
                    client.player != null ? client.player.getUuid() : null);
                if (entry != null && entry.getLatency() > 0)
                    estimatedPingMs.set(entry.getLatency());
            } catch (Exception ignored) {}
        }
    }

    // ─────────────────────────────────────────────────────────────
    private void processNext() {
        if (!busy.compareAndSet(false, true)) return;
        BlockPos railPos = queue.poll();
        if (railPos == null) { busy.set(false); return; }

        AsyncRunner.run(() -> {
            try {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player == null || !enabled) { busy.set(false); return; }
                if (!RotationUtil.inReach(mc.player, railPos)) {
                    busy.set(false); drainNext(); return;
                }

                // Check inventory trước
                final int[] slots = { -1, -1 };
                safeExecute(mc, () -> {
                    if (mc.player == null) return;
                    slots[0] = findInHotbar(mc.player, Items.RAIL);
                    if (slots[0] == -1)
                        slots[0] = findInHotbar(mc.player, Items.POWERED_RAIL);
                    slots[1] = findInHotbar(mc.player, Items.TNT_MINECART);
                });
                if (slots[0] == -1) { busy.set(false); drainNext(); return; }

                long pingMs    = estimatedPingMs.get();
                long pingBonus = pingMs > 150 ? (pingMs - 150) / 4 : 0L;

                // === STEP 1: Gradual rotation về phía block ===
                // Lerp qua 3 tick thay vì teleport ngay
                final float[] targetRot = { 0, 0 };
                final float[] savedRot  = { 0, 0 };
                safeExecute(mc, () -> {
                    if (mc.player == null) return;
                    float[] r = RotationUtil.calcRotation(mc.player, railPos.down());
                    targetRot[0] = r[0]; targetRot[1] = r[1];
                    savedRot[0]  = mc.player.getYaw();
                    savedRot[1]  = mc.player.getPitch();
                });

                for (int step = 1; step <= ROTATION_STEPS; step++) {
                    final float t = (float) step / ROTATION_STEPS;
                    safeExecute(mc, () -> {
                        if (mc.player == null) return;
                        float yaw   = lerpAngle(savedRot[0], targetRot[0], t);
                        float pitch = lerp(savedRot[1], targetRot[1], t);
                        RotationUtil.applySilent(mc.player, new float[]{ yaw, pitch });
                    });
                    Thread.sleep(ROTATION_STEP_MS);
                }

                // === STEP 2: Pre-slot delay (scroll wheel feel) ===
                Thread.sleep(PRE_SLOT_DELAY_MS + pingBonus);
                tickSync.awaitNextTick(100L);

                // === STEP 3: Switch slot + swing + đặt Rail ===
                boolean[] railOk    = { false };
                final int[] savedSlot = { 0 };

                safeExecute(mc, () -> {
                    if (mc.player == null || mc.interactionManager == null) return;
                    savedSlot[0] = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = slots[0];

                    // Swing arm TRƯỚC — Grim/Vulcan check sequence này
                    mc.player.swingHand(Hand.MAIN_HAND);
                });

                // Delay nhỏ giữa swing và interact (~1 tick)
                Thread.sleep(ROTATION_STEP_MS);
                tickSync.awaitNextTick(100L);

                safeExecute(mc, () -> {
                    if (mc.player == null || mc.interactionManager == null) return;
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new BlockHitResult(
                            Vec3d.ofCenter(railPos).add(0, -0.5, 0),
                            Direction.UP, railPos.down(), false));
                    railOk[0] = true;
                });

                if (!railOk[0]) { restoreAndExit(mc, savedRot, savedSlot[0]); return; }

                // Nếu không có cart → restore rồi dừng
                if (slots[1] == -1) {
                    restoreAndExit(mc, savedRot, savedSlot[0]);
                    return;
                }

                // === STEP 4: Rail→Cart delay với gaussian random ===
                long railToCart = gaussianDelay(RAIL_TO_CART_MS, RAIL_TO_CART_STD) + pingBonus;
                Thread.sleep(Math.max(80L, railToCart));

                // Rotate về phía rail (hơi khác góc — trông natural)
                safeExecute(mc, () -> {
                    if (mc.player == null) return;
                    float[] r2 = RotationUtil.calcRotation(mc.player, railPos);
                    RotationUtil.applySilent(mc.player, r2);
                });

                tickSync.awaitNextTick(100L);

                // === STEP 5: Swing + đặt TNT Cart ===
                safeExecute(mc, () -> {
                    if (mc.player == null || mc.interactionManager == null) return;

                    boolean hasRail =
                        mc.world.getBlockState(railPos).isOf(Blocks.RAIL) ||
                        mc.world.getBlockState(railPos).isOf(Blocks.POWERED_RAIL);
                    if (!hasRail) return;

                    int cartSlot = findInHotbar(mc.player, Items.TNT_MINECART);
                    if (cartSlot == -1) return;

                    mc.player.getInventory().selectedSlot = cartSlot;
                    mc.player.swingHand(Hand.MAIN_HAND);
                });

                Thread.sleep(ROTATION_STEP_MS);
                tickSync.awaitNextTick(100L);

                safeExecute(mc, () -> {
                    if (mc.player == null || mc.interactionManager == null) return;
                    boolean hasRail =
                        mc.world.getBlockState(railPos).isOf(Blocks.RAIL) ||
                        mc.world.getBlockState(railPos).isOf(Blocks.POWERED_RAIL);
                    if (!hasRail) return;
                    int cartSlot = findInHotbar(mc.player, Items.TNT_MINECART);
                    if (cartSlot == -1) return;

                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new BlockHitResult(
                            Vec3d.ofCenter(railPos).add(0, 0.1, 0),
                            Direction.UP, railPos, false));
                });

                // === STEP 6: Restore rotation + slot ===
                long restoreDelay = gaussianDelay(SLOT_RESTORE_MS, SLOT_RESTORE_STD);
                Thread.sleep(Math.max(60L, restoreDelay));

                restoreAndExit(mc, savedRot, savedSlot[0]);

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception ignored) {
            } finally {
                lastActionMs = System.currentTimeMillis();
                busy.set(false);
                drainNext();
            }
        });
    }

    private void restoreAndExit(MinecraftClient mc, float[] savedRot, int savedSlot) {
        try {
            Thread.sleep(ROTATION_STEP_MS * 2);
            safeExecute(mc, () -> {
                if (mc.player == null) return;
                // Lerp rotation về lại từ từ
                RotationUtil.applySilent(mc.player, savedRot);
                mc.player.getInventory().selectedSlot = savedSlot;
            });
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Gaussian random delay — phân phối tự nhiên hơn uniform random. */
    private long gaussianDelay(long mean, long std) {
        double g = ThreadLocalRandom.current().nextGaussian();
        return mean + (long)(g * std);
    }

    /** Linear interpolation cho float. */
    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Lerp góc — xử lý wrap-around 360°. */
    private float lerpAngle(float a, float b, float t) {
        float diff = b - a;
        while (diff > 180f)  diff -= 360f;
        while (diff < -180f) diff += 360f;
        return a + diff * t;
    }

    private void safeExecute(MinecraftClient mc, Runnable action) {
        final boolean[] done = { false };
        mc.execute(() -> {
            try { action.run(); }
            catch (Exception ignored) {}
            finally {
                synchronized (done) { done[0] = true; done.notifyAll(); }
            }
        });
        synchronized (done) {
            long deadline = System.currentTimeMillis() + 300L;
            while (!done[0]) {
                long rem = deadline - System.currentTimeMillis();
                if (rem <= 0) break;
                try { done.wait(rem); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        }
    }

    private void drainNext() {
        if (!queue.isEmpty() && !busy.get()) processNext();
    }

    private int findInHotbar(ClientPlayerEntity player, net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == item) return i;
        }
        return -1;
    }
}
