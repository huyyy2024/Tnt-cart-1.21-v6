package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.PlacementCalc;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * FireArrowMixin v5:
 *
 * Lag compensation: trigger window mở rộng theo ping.
 *   ping < 100ms  → 8 tick  (nhanh)
 *   ping 100-200ms → 12 tick
 *   ping 200-300ms → 16 tick
 *   ping > 300ms   → 20 tick (lag nặng)
 *
 * Lý do: khi lag, packet đặt rail cần nhiều thời gian hơn để server nhận,
 * nên phải trigger sớm hơn để cart kịp spawn trước khi tên đến.
 */
@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    private boolean firebow$hasQueued = false;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (firebow$hasQueued) return;
        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;

        World world    = self.getWorld();
        Vec3d pos      = self.getPos();
        Vec3d velocity = self.getVelocity();

        BlockPos railPos = PlacementCalc.predictLandingRailPos(world, pos, velocity);
        if (railPos == null) return;

        int ticksLeft = estimateTicksToLand(pos, velocity, railPos);

        // Tính trigger window dựa theo ping
        int triggerWindow = calcTriggerWindow(rt.getPingMs());

        if (ticksLeft <= triggerWindow) {
            rt.enqueue(railPos);
            firebow$hasQueued = true;
        }
    }

    /**
     * Trigger window theo ping:
     * đảm bảo rail + cart spawn đúng lúc dù server lag.
     */
    private int calcTriggerWindow(long pingMs) {
        if (pingMs < 100)  return 8;
        if (pingMs < 200)  return 12;
        if (pingMs < 300)  return 16;
        return 20;
    }

    private int estimateTicksToLand(Vec3d pos, Vec3d vel, BlockPos target) {
        double x  = pos.x, y  = pos.y, z  = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        Vec3d  t  = Vec3d.ofCenter(target);

        for (int i = 0; i < 60; i++) {
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;
            double dist = Math.sqrt(
                (x-t.x)*(x-t.x) + (y-t.y)*(y-t.y) + (z-t.z)*(z-t.z));
            if (dist < 1.5) return i;
        }
        return 60;
    }

    private boolean isOwnArrow(PersistentProjectileEntity arrow, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = arrow.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
