package com.firebow.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AsyncRunner v4 — thêm ThreadFactory tên rõ ràng để debug dễ hơn.
 * Logic không đổi, chỉ làm sạch.
 */
public final class AsyncRunner {

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "firebow-worker");
        t.setDaemon(true);
        t.setUncaughtExceptionHandler((thread, ex) -> {
            // Log but don't crash — prevents silent death of worker thread
            System.err.println("[FireBow] Worker uncaught exception: " + ex.getMessage());
        });
        return t;
    });

    private AsyncRunner() {}

    public static void run(Runnable action) {
        EXECUTOR.execute(action);
    }

    public static void runDelayed(Runnable action, long delayMs) {
        EXECUTOR.execute(() -> {
            try {
                Thread.sleep(delayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            action.run();
        });
    }
}
